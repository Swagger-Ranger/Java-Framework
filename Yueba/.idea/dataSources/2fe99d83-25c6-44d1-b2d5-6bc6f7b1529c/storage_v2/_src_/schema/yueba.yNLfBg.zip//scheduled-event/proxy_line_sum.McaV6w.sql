create definer = root@`%` event proxy_line_sum
  on schedule
    every '1' DAY
      starts '2018-04-08 04:00:00'
  enable
do
  CALL `proxy_line_sum`();

