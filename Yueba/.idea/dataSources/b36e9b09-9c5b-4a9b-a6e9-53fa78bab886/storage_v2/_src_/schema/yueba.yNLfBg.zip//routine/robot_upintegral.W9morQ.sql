create procedure robot_upintegral()
  BEGIN
	declare n int;
	declare m int;
	declare a int;
	declare b int;
	declare c int;
	set n=2000;
	set m=10;
	set a=1;
	set b=300;
	set c=1;
	while a<=30 do 
		update robot set integral=n+m where id=a;
		set m=m+10;
		set a=a+1;
	end while;
	while a>30&&a<=100 do 
		update robot set integral=b+c where id=a;
		set c=c+3;
		set a=a+1;
	end while;
END;

