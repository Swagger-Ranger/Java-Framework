create trigger insert_integral_change_to_robot
  after UPDATE
  on robot
  for each row
  BEGIN
	IF new.integral!=old.integral THEN
	INSERT INTO robot_integral_change_log VALUES (NULL,new.`id`,old.integral,new.integral,(new.integral-old.integral),CURRENT_TIMESTAMP());
	END IF;	
    END;

