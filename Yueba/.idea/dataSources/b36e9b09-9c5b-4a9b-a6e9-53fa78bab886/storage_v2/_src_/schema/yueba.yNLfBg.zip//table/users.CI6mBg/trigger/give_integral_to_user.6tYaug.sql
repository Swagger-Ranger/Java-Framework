create trigger give_integral_to_user
  before INSERT
  on users
  for each row
  BEGIN
	declare isGive boolean default false; 
	DECLARE giveAmount int DEFAULT 0; 
	DECLARE giveId INT DEFAULT 0;
	SELECT id,IF(id IS NULL,FALSE,TRUE),IFNULL(amount,0) INTO giveId,isGive,giveAmount FROM give_integral_settings settings 
	WHERE is_on = 1 AND number > have_number ORDER BY SERIAL ASC LIMIT 1;
	if isGive then
		SET NEW.`integral` = NEW.`integral` + giveAmount;
		UPDATE `give_integral_settings` SET `have_number` = `have_number` + 1  WHERE id = giveId;
		INSERT INTO `yueba`.`give_integral_log` (`user_account`,`amount`,`create_time`) 
		VALUES (NEW.account,giveAmount,now()) ;
	end if;
    END;

