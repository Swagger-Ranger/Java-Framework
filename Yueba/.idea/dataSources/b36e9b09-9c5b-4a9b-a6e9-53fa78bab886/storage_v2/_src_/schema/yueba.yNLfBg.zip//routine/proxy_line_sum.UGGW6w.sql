create procedure proxy_line_sum()
  BEGIN

	#1、获取需要查看数据的用户

	#2、当前用户下线所有用户

	#3、获取这些用户应该结算的返利（由记录中最大的一天开始截止到触发结算的头一天，开始时间和结束时间，为最大的下一天和触发结算的头一天）

	#4、生成用户结算数据

	INSERT INTO `users_line_sum_log`(`user_id`,`value`,`start_time`,`end_time`) 

	SELECT 

	p.id,

	SUM(flow.`value`) AS VALUE,

	DATE_FORMAT( flow.`create_time`, "%Y-%m-%d 00:00:00") AS start_time, 

	DATE_ADD(DATE_FORMAT( flow.`create_time`, "%Y-%m-%d 00:00:00"),INTERVAL 1 DAY)

	AS end_time

	FROM `proxy` p 

	INNER JOIN `users_line_relation` re ON re.`line_user_id` = p.`id`  AND p.kg = 1 AND p.`right` = 1

	#查找代理

	inner join `proxy` pu on pu.uid = re.`user_id`

	INNER JOIN `users_funds_flow_log` flow ON flow.`user_id` = pu.`id` AND flow.`flow_type` = 0 AND flow.`value_type` = 0

	LEFT JOIN 

	( SELECT MAX(end_time) AS timer,user_id FROM `users_line_sum_log` GROUP BY `user_id`) AS user_sum ON 

	user_sum.user_id = p.`id` 

	WHERE 

	(

		flow.`create_time` >= user_sum.timer AND flow.`create_time` < CAST(CAST(SYSDATE()AS DATE)AS DATETIME)

	) OR user_sum.user_id IS NULL

	GROUP BY p.id,DATE_FORMAT( flow.`create_time`, "%Y-%m-%d");

	    END;

